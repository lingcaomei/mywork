app.directive('pgValidateEmail', function(){
	// Runs during compile
	return {
		// name: '',
		// priority: 1,
		// terminal: true,
		// scope: {}, // {} = isolate, true = child, false/undefined = no change
		// controller: function($scope, $element, $attrs, $transclude) {},
		 require: 'ngModel', // Array = multiple requires, ? = optional, ^ = check parent elements
		 restrict: 'A', // E = Element, A = Attribute, C = Class, M = Comment
		// template: '',
		// templateUrl: '',
		// replace: true,
		// transclude: true,
		// compile: function(tElement, tAttrs, function transclude(function(scope, cloneLinkingFn){ return function linking(scope, elm, attrs){}})),
		link: function($scope, iElm, iAttrs, ngModel, controller) {
			ngModel.$parsers.unshift(function(viewValue) {
				var patrn = /^[\w-]+@[\w-]+(\.[\w-]+)+$/;
        		var result = patrn.test(viewValue);
        		if(result) {
        			ngModel.$setValidity('pgValidateEmail', true);
        			return viewValue;
        		}
        		else {
        			ngModel.$setValidity('pgValidateEmail', false);
        			return undefined;
        		}
			});
		}
	};
});